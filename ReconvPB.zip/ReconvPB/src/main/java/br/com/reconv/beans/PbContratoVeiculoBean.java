/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.reconv.beans;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.*;
import br.com.reconv.entitys.*;
import br.com.reconv.facade.PbContratoVeiculoFacade;
import javax.ejb.EJB;


/**
 *
 * @author cdi_mfprado
 */
@Named(value = "pbContratoVeiculoBean")
@SessionScoped
public class PbContratoVeiculoBean implements Serializable {

    @EJB
    private PbContratoVeiculoFacade pbContratoVeiculoFacade;
    private PbContratoVeiculo pbContratoVeiculo = new PbContratoVeiculo();

    public PbContratoVeiculo getPbContratoVeiculo() {
        return pbContratoVeiculo;
    }

    public void setPbContratoVeiculo(PbContratoVeiculo pbContratoVeiculo) {
        this.pbContratoVeiculo = pbContratoVeiculo;
    }
    
    public List<PbContratoVeiculo> findAll() {
        return this.pbContratoVeiculoFacade.findAll();
    }
    /**
     * Creates a new instance of PbContratoVeiculoBean
     */
    public PbContratoVeiculoBean() {
    }
    
}
