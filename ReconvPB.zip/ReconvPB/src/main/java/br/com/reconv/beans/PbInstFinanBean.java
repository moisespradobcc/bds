/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.reconv.beans;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.*;
import br.com.reconv.entitys.*;
import br.com.reconv.facade.PbInstFinanFacade;
import javax.ejb.EJB;

/**
 *
 * @author cdi_mfprado
 */
@Named(value = "pbInstFinanBean")
@SessionScoped
public class PbInstFinanBean implements Serializable {

    @EJB
    private PbInstFinanFacade pbInstFinanFacade;
    private PbInstFinan pbInstFinan = new PbInstFinan();

    public PbInstFinan getPbInstFinan() {
        return pbInstFinan;
    }

    public void setPbInstFinan(PbInstFinan pbInstFinan) {
        this.pbInstFinan = pbInstFinan;
    }

    public PbInstFinanBean() {
    }

    public List<PbInstFinan> findAll() {
        return this.pbInstFinanFacade.findAll();

    }

    public String addInstFinan() {
        this.pbInstFinan.setPbDtReg(new Date());
        this.pbInstFinan.setPbDtUltAtu(new Date().toString());
        this.pbInstFinanFacade.create(this.pbInstFinan);
        this.pbInstFinan = new PbInstFinan();
        return "/pbInstFinan/listInstFinan";
    }

    public String delete(PbInstFinan pbInstFinan) {
        this.pbInstFinanFacade.remove(pbInstFinan);
        return "/pbInstFinan/listInstFinan";
    }

    public String buscaInstFinan(PbInstFinan pbInstFinan) {
        this.pbInstFinan = pbInstFinan;
        return "/pbInstFinan/editInstFinan";
    }

    public String editInstFinan() {
        this.pbInstFinan.setPbDtUltAtu(new Date().toString());
        this.pbInstFinanFacade.edit(this.pbInstFinan);
        this.pbInstFinan = new PbInstFinan();
        return "/pbInstFinan/listInstFinan";
    }
}
