package br.com.reconv.beans;

import br.com.reconv.facade.PbUsuarioFacade;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.*;
import javax.ejb.EJB;
import br.com.reconv.entitys.*;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author cdi_mfprado
 */
@Named(value = "pbUsuarioBean")
@SessionScoped
public class PbUsuarioBean implements Serializable {

    @EJB
    private PbUsuarioFacade pbUsuarioFacade;
    private PbUsuario pbUsuario = new PbUsuario();

    public PbUsuario getPbUsuario() {
        return pbUsuario;
    }

    public void setPbUsuario(PbUsuario pbUsuario) {
        this.pbUsuario = pbUsuario;
    }

    public PbUsuarioBean() {
    }

    public List<PbUsuario> findAll() {
        return this.pbUsuarioFacade.findAll();
    }

    public String addUser() {
        this.pbUsuario.setUsuDtReg(new Date());
        this.pbUsuarioFacade.create(this.pbUsuario);
        this.pbUsuario = new PbUsuario();
        return "/pbUsuario/listUsuario";

    }

    public void delete(PbUsuario pbUsuario) {
        this.pbUsuarioFacade.remove(pbUsuario);
    }

    public String buscaUsuario(PbUsuario pbUsuario) {
        this.pbUsuario = pbUsuario;
        return "/pbUsuario/editUsuario";
    }

    public String editUsuario() {
        this.pbUsuario.setUsuDtUltAtu(new Date());
        this.pbUsuarioFacade.edit(this.pbUsuario);
        this.pbUsuario = new PbUsuario();
        return "/pbUsuario/listUsuario";
    }

}
