/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.reconv.entitys;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author cdi_mfprado
 */
@Entity
@Table(name = "pb_contrato_veiculo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PbContratoVeiculo.findAll", query = "SELECT p FROM PbContratoVeiculo p")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbIdCont", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbIdCont = :pbIdCont")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContNomeDevedor", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContNomeDevedor = :pbContNomeDevedor")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContCpfCnpj", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContCpfCnpj = :pbContCpfCnpj")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContTelefone", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContTelefone = :pbContTelefone")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContCep", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContCep = :pbContCep")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContUf", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContUf = :pbContUf")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContMunicipio", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContMunicipio = :pbContMunicipio")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContBairro", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContBairro = :pbContBairro")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContNumero", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContNumero = :pbContNumero")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContComplemento", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContComplemento = :pbContComplemento")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContLogradouro", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContLogradouro = :pbContLogradouro")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContChassi", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContChassi = :pbContChassi")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContTipoVeiculo", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContTipoVeiculo = :pbContTipoVeiculo")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContMotor", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContMotor = :pbContMotor")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContPlaca", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContPlaca = :pbContPlaca")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContTipo", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContTipo = :pbContTipo")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContAditivo", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContAditivo = :pbContAditivo")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContNum", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContNum = :pbContNum")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContDtContrato", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContDtContrato = :pbContDtContrato")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContValorTaxaContrato", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContValorTaxaContrato = :pbContValorTaxaContrato")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContTaxaJurosMes", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContTaxaJurosMes = :pbContTaxaJurosMes")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContTaxaJurosAno", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContTaxaJurosAno = :pbContTaxaJurosAno")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContTotalFinanciamento", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContTotalFinanciamento = :pbContTotalFinanciamento")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContIndicativoJurosMulta", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContIndicativoJurosMulta = :pbContIndicativoJurosMulta")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContValorJurosMulta", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContValorJurosMulta = :pbContValorJurosMulta")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContIndicativoMoraDia", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContIndicativoMoraDia = :pbContIndicativoMoraDia")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContValorMoraDia", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContValorMoraDia = :pbContValorMoraDia")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContValorIof", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContValorIof = :pbContValorIof")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContQuantidadeParcela", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContQuantidadeParcela = :pbContQuantidadeParcela")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContValorParcela", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContValorParcela = :pbContValorParcela")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContVencPrimeiraParcela", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContVencPrimeiraParcela = :pbContVencPrimeiraParcela")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContVencUltimaParcela", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContVencUltimaParcela = :pbContVencUltimaParcela")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContComissao", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContComissao = :pbContComissao")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContValorComissao", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContValorComissao = :pbContValorComissao")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContDataCredito", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContDataCredito = :pbContDataCredito")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContUfPagamento", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContUfPagamento = :pbContUfPagamento")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContCidadePagamento", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContCidadePagamento = :pbContCidadePagamento")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContIndicativoPenalidade", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContIndicativoPenalidade = :pbContIndicativoPenalidade")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContPenalidade", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContPenalidade = :pbContPenalidade")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContDescricaoTaxaJuros", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContDescricaoTaxaJuros = :pbContDescricaoTaxaJuros")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContIndice", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContIndice = :pbContIndice")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContNumeroGrupo", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContNumeroGrupo = :pbContNumeroGrupo")
    , @NamedQuery(name = "PbContratoVeiculo.findByPbContNumeroCota", query = "SELECT p FROM PbContratoVeiculo p WHERE p.pbContNumeroCota = :pbContNumeroCota")})
public class PbContratoVeiculo implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "pb_id_cont")
    private Integer pbIdCont;
    @Size(max = 50)
    @Column(name = "pb_cont_nome_devedor")
    private String pbContNomeDevedor;
    @Size(max = 14)
    @Column(name = "pb_cont_cpf_cnpj")
    private String pbContCpfCnpj;
    @Size(max = 10)
    @Column(name = "pb_cont_telefone")
    private String pbContTelefone;
    @Size(max = 10)
    @Column(name = "pb_cont_cep")
    private String pbContCep;
    @Size(max = 2)
    @Column(name = "pb_cont_uf")
    private String pbContUf;
    @Size(max = 50)
    @Column(name = "pb_cont_municipio")
    private String pbContMunicipio;
    @Size(max = 50)
    @Column(name = "pb_cont_bairro")
    private String pbContBairro;
    @Size(max = 50)
    @Column(name = "pb_cont_numero")
    private String pbContNumero;
    @Size(max = 50)
    @Column(name = "pb_cont_complemento")
    private String pbContComplemento;
    @Size(max = 50)
    @Column(name = "pb_cont_logradouro")
    private String pbContLogradouro;
    @Size(max = 50)
    @Column(name = "pb_cont_chassi")
    private String pbContChassi;
    @Column(name = "pb_cont_tipo_veiculo")
    private Character pbContTipoVeiculo;
    @Size(max = 20)
    @Column(name = "pb_cont_motor")
    private String pbContMotor;
    @Size(max = 20)
    @Column(name = "pb_cont_placa")
    private String pbContPlaca;
    @Size(max = 12)
    @Column(name = "pb_cont_tipo")
    private String pbContTipo;
    @Size(max = 10)
    @Column(name = "pb_cont_aditivo")
    private String pbContAditivo;
    @Size(max = 20)
    @Column(name = "pb_cont_num")
    private String pbContNum;
    @Column(name = "pb_cont_dt_contrato")
    @Temporal(TemporalType.TIMESTAMP)
    private Date pbContDtContrato;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "pb_cont_valor_taxa_contrato")
    private BigDecimal pbContValorTaxaContrato;
    @Column(name = "pb_cont_taxa_juros_mes")
    private BigDecimal pbContTaxaJurosMes;
    @Column(name = "pb_cont_taxa_juros_ano")
    private BigDecimal pbContTaxaJurosAno;
    @Column(name = "pb_cont_total_financiamento")
    private BigDecimal pbContTotalFinanciamento;
    @Column(name = "pb_cont_indicativo_juros_multa")
    private Character pbContIndicativoJurosMulta;
    @Column(name = "pb_cont_valor_juros_multa")
    private BigDecimal pbContValorJurosMulta;
    @Column(name = "pb_cont_indicativo_mora_dia")
    private Character pbContIndicativoMoraDia;
    @Column(name = "pb_cont_valor_mora_dia")
    private BigDecimal pbContValorMoraDia;
    @Column(name = "pb_cont_valor_iof")
    private BigDecimal pbContValorIof;
    @Column(name = "pb_cont_quantidade_parcela")
    private Integer pbContQuantidadeParcela;
    @Column(name = "pb_cont_valor_parcela")
    private BigDecimal pbContValorParcela;
    @Column(name = "pb_cont_venc_primeira_parcela")
    @Temporal(TemporalType.TIMESTAMP)
    private Date pbContVencPrimeiraParcela;
    @Column(name = "pb_cont_venc_ultima_parcela")
    @Temporal(TemporalType.TIMESTAMP)
    private Date pbContVencUltimaParcela;
    @Size(max = 2)
    @Column(name = "pb_cont_comissao")
    private String pbContComissao;
    @Column(name = "pb_cont_valor_comissao")
    private BigDecimal pbContValorComissao;
    @Column(name = "pb_cont_data_credito")
    @Temporal(TemporalType.TIMESTAMP)
    private Date pbContDataCredito;
    @Size(max = 2)
    @Column(name = "pb_cont_uf_pagamento")
    private String pbContUfPagamento;
    @Size(max = 50)
    @Column(name = "pb_cont_cidade_pagamento")
    private String pbContCidadePagamento;
    @Column(name = "pb_cont_indicativo_penalidade")
    private Character pbContIndicativoPenalidade;
    @Column(name = "pb_cont_penalidade")
    private BigDecimal pbContPenalidade;
    @Size(max = 50)
    @Column(name = "pb_cont_descricao_taxa_juros")
    private String pbContDescricaoTaxaJuros;
    @Size(max = 50)
    @Column(name = "pb_cont_indice")
    private String pbContIndice;
    @Size(max = 50)
    @Column(name = "pb_cont_numero_grupo")
    private String pbContNumeroGrupo;
    @Size(max = 50)
    @Column(name = "pb_cont_numero_cota")
    private String pbContNumeroCota;

    public PbContratoVeiculo() {
    }

    public PbContratoVeiculo(Integer pbIdCont) {
        this.pbIdCont = pbIdCont;
    }

    public Integer getPbIdCont() {
        return pbIdCont;
    }

    public void setPbIdCont(Integer pbIdCont) {
        this.pbIdCont = pbIdCont;
    }

    public String getPbContNomeDevedor() {
        return pbContNomeDevedor;
    }

    public void setPbContNomeDevedor(String pbContNomeDevedor) {
        this.pbContNomeDevedor = pbContNomeDevedor;
    }

    public String getPbContCpfCnpj() {
        return pbContCpfCnpj;
    }

    public void setPbContCpfCnpj(String pbContCpfCnpj) {
        this.pbContCpfCnpj = pbContCpfCnpj;
    }

    public String getPbContTelefone() {
        return pbContTelefone;
    }

    public void setPbContTelefone(String pbContTelefone) {
        this.pbContTelefone = pbContTelefone;
    }

    public String getPbContCep() {
        return pbContCep;
    }

    public void setPbContCep(String pbContCep) {
        this.pbContCep = pbContCep;
    }

    public String getPbContUf() {
        return pbContUf;
    }

    public void setPbContUf(String pbContUf) {
        this.pbContUf = pbContUf;
    }

    public String getPbContMunicipio() {
        return pbContMunicipio;
    }

    public void setPbContMunicipio(String pbContMunicipio) {
        this.pbContMunicipio = pbContMunicipio;
    }

    public String getPbContBairro() {
        return pbContBairro;
    }

    public void setPbContBairro(String pbContBairro) {
        this.pbContBairro = pbContBairro;
    }

    public String getPbContNumero() {
        return pbContNumero;
    }

    public void setPbContNumero(String pbContNumero) {
        this.pbContNumero = pbContNumero;
    }

    public String getPbContComplemento() {
        return pbContComplemento;
    }

    public void setPbContComplemento(String pbContComplemento) {
        this.pbContComplemento = pbContComplemento;
    }

    public String getPbContLogradouro() {
        return pbContLogradouro;
    }

    public void setPbContLogradouro(String pbContLogradouro) {
        this.pbContLogradouro = pbContLogradouro;
    }

    public String getPbContChassi() {
        return pbContChassi;
    }

    public void setPbContChassi(String pbContChassi) {
        this.pbContChassi = pbContChassi;
    }

    public Character getPbContTipoVeiculo() {
        return pbContTipoVeiculo;
    }

    public void setPbContTipoVeiculo(Character pbContTipoVeiculo) {
        this.pbContTipoVeiculo = pbContTipoVeiculo;
    }

    public String getPbContMotor() {
        return pbContMotor;
    }

    public void setPbContMotor(String pbContMotor) {
        this.pbContMotor = pbContMotor;
    }

    public String getPbContPlaca() {
        return pbContPlaca;
    }

    public void setPbContPlaca(String pbContPlaca) {
        this.pbContPlaca = pbContPlaca;
    }

    public String getPbContTipo() {
        return pbContTipo;
    }

    public void setPbContTipo(String pbContTipo) {
        this.pbContTipo = pbContTipo;
    }

    public String getPbContAditivo() {
        return pbContAditivo;
    }

    public void setPbContAditivo(String pbContAditivo) {
        this.pbContAditivo = pbContAditivo;
    }

    public String getPbContNum() {
        return pbContNum;
    }

    public void setPbContNum(String pbContNum) {
        this.pbContNum = pbContNum;
    }

    public Date getPbContDtContrato() {
        return pbContDtContrato;
    }

    public void setPbContDtContrato(Date pbContDtContrato) {
        this.pbContDtContrato = pbContDtContrato;
    }

    public BigDecimal getPbContValorTaxaContrato() {
        return pbContValorTaxaContrato;
    }

    public void setPbContValorTaxaContrato(BigDecimal pbContValorTaxaContrato) {
        this.pbContValorTaxaContrato = pbContValorTaxaContrato;
    }

    public BigDecimal getPbContTaxaJurosMes() {
        return pbContTaxaJurosMes;
    }

    public void setPbContTaxaJurosMes(BigDecimal pbContTaxaJurosMes) {
        this.pbContTaxaJurosMes = pbContTaxaJurosMes;
    }

    public BigDecimal getPbContTaxaJurosAno() {
        return pbContTaxaJurosAno;
    }

    public void setPbContTaxaJurosAno(BigDecimal pbContTaxaJurosAno) {
        this.pbContTaxaJurosAno = pbContTaxaJurosAno;
    }

    public BigDecimal getPbContTotalFinanciamento() {
        return pbContTotalFinanciamento;
    }

    public void setPbContTotalFinanciamento(BigDecimal pbContTotalFinanciamento) {
        this.pbContTotalFinanciamento = pbContTotalFinanciamento;
    }

    public Character getPbContIndicativoJurosMulta() {
        return pbContIndicativoJurosMulta;
    }

    public void setPbContIndicativoJurosMulta(Character pbContIndicativoJurosMulta) {
        this.pbContIndicativoJurosMulta = pbContIndicativoJurosMulta;
    }

    public BigDecimal getPbContValorJurosMulta() {
        return pbContValorJurosMulta;
    }

    public void setPbContValorJurosMulta(BigDecimal pbContValorJurosMulta) {
        this.pbContValorJurosMulta = pbContValorJurosMulta;
    }

    public Character getPbContIndicativoMoraDia() {
        return pbContIndicativoMoraDia;
    }

    public void setPbContIndicativoMoraDia(Character pbContIndicativoMoraDia) {
        this.pbContIndicativoMoraDia = pbContIndicativoMoraDia;
    }

    public BigDecimal getPbContValorMoraDia() {
        return pbContValorMoraDia;
    }

    public void setPbContValorMoraDia(BigDecimal pbContValorMoraDia) {
        this.pbContValorMoraDia = pbContValorMoraDia;
    }

    public BigDecimal getPbContValorIof() {
        return pbContValorIof;
    }

    public void setPbContValorIof(BigDecimal pbContValorIof) {
        this.pbContValorIof = pbContValorIof;
    }

    public Integer getPbContQuantidadeParcela() {
        return pbContQuantidadeParcela;
    }

    public void setPbContQuantidadeParcela(Integer pbContQuantidadeParcela) {
        this.pbContQuantidadeParcela = pbContQuantidadeParcela;
    }

    public BigDecimal getPbContValorParcela() {
        return pbContValorParcela;
    }

    public void setPbContValorParcela(BigDecimal pbContValorParcela) {
        this.pbContValorParcela = pbContValorParcela;
    }

    public Date getPbContVencPrimeiraParcela() {
        return pbContVencPrimeiraParcela;
    }

    public void setPbContVencPrimeiraParcela(Date pbContVencPrimeiraParcela) {
        this.pbContVencPrimeiraParcela = pbContVencPrimeiraParcela;
    }

    public Date getPbContVencUltimaParcela() {
        return pbContVencUltimaParcela;
    }

    public void setPbContVencUltimaParcela(Date pbContVencUltimaParcela) {
        this.pbContVencUltimaParcela = pbContVencUltimaParcela;
    }

    public String getPbContComissao() {
        return pbContComissao;
    }

    public void setPbContComissao(String pbContComissao) {
        this.pbContComissao = pbContComissao;
    }

    public BigDecimal getPbContValorComissao() {
        return pbContValorComissao;
    }

    public void setPbContValorComissao(BigDecimal pbContValorComissao) {
        this.pbContValorComissao = pbContValorComissao;
    }

    public Date getPbContDataCredito() {
        return pbContDataCredito;
    }

    public void setPbContDataCredito(Date pbContDataCredito) {
        this.pbContDataCredito = pbContDataCredito;
    }

    public String getPbContUfPagamento() {
        return pbContUfPagamento;
    }

    public void setPbContUfPagamento(String pbContUfPagamento) {
        this.pbContUfPagamento = pbContUfPagamento;
    }

    public String getPbContCidadePagamento() {
        return pbContCidadePagamento;
    }

    public void setPbContCidadePagamento(String pbContCidadePagamento) {
        this.pbContCidadePagamento = pbContCidadePagamento;
    }

    public Character getPbContIndicativoPenalidade() {
        return pbContIndicativoPenalidade;
    }

    public void setPbContIndicativoPenalidade(Character pbContIndicativoPenalidade) {
        this.pbContIndicativoPenalidade = pbContIndicativoPenalidade;
    }

    public BigDecimal getPbContPenalidade() {
        return pbContPenalidade;
    }

    public void setPbContPenalidade(BigDecimal pbContPenalidade) {
        this.pbContPenalidade = pbContPenalidade;
    }

    public String getPbContDescricaoTaxaJuros() {
        return pbContDescricaoTaxaJuros;
    }

    public void setPbContDescricaoTaxaJuros(String pbContDescricaoTaxaJuros) {
        this.pbContDescricaoTaxaJuros = pbContDescricaoTaxaJuros;
    }

    public String getPbContIndice() {
        return pbContIndice;
    }

    public void setPbContIndice(String pbContIndice) {
        this.pbContIndice = pbContIndice;
    }

    public String getPbContNumeroGrupo() {
        return pbContNumeroGrupo;
    }

    public void setPbContNumeroGrupo(String pbContNumeroGrupo) {
        this.pbContNumeroGrupo = pbContNumeroGrupo;
    }

    public String getPbContNumeroCota() {
        return pbContNumeroCota;
    }

    public void setPbContNumeroCota(String pbContNumeroCota) {
        this.pbContNumeroCota = pbContNumeroCota;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pbIdCont != null ? pbIdCont.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PbContratoVeiculo)) {
            return false;
        }
        PbContratoVeiculo other = (PbContratoVeiculo) object;
        if ((this.pbIdCont == null && other.pbIdCont != null) || (this.pbIdCont != null && !this.pbIdCont.equals(other.pbIdCont))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.com.reconv.entitys.PbContratoVeiculo[ pbIdCont=" + pbIdCont + " ]";
    }
    
}
