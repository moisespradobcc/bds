/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.reconv.entitys;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author cdi_mfprado
 */
@Entity
@Table(name = "pb_inst_finan")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PbInstFinan.findAll", query = "SELECT p FROM PbInstFinan p")
    , @NamedQuery(name = "PbInstFinan.findByPbId", query = "SELECT p FROM PbInstFinan p WHERE p.pbId = :pbId")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanCnpj", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanCnpj = :pbFinanCnpj")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanRazSocial", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanRazSocial = :pbFinanRazSocial")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanCodDetran", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanCodDetran = :pbFinanCodDetran")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanCep", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanCep = :pbFinanCep")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanLogr", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanLogr = :pbFinanLogr")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanNum", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanNum = :pbFinanNum")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanUf", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanUf = :pbFinanUf")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanCidade", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanCidade = :pbFinanCidade")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanBairro", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanBairro = :pbFinanBairro")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanCidadeAcad", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanCidadeAcad = :pbFinanCidadeAcad")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanComple", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanComple = :pbFinanComple")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanEmail", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanEmail = :pbFinanEmail")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanTel", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanTel = :pbFinanTel")
    , @NamedQuery(name = "PbInstFinan.findByPbFinanCel", query = "SELECT p FROM PbInstFinan p WHERE p.pbFinanCel = :pbFinanCel")
    , @NamedQuery(name = "PbInstFinan.findByPbDtReg", query = "SELECT p FROM PbInstFinan p WHERE p.pbDtReg = :pbDtReg")
    , @NamedQuery(name = "PbInstFinan.findByPbDtUltAtu", query = "SELECT p FROM PbInstFinan p WHERE p.pbDtUltAtu = :pbDtUltAtu")})
public class PbInstFinan implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "pb_id")
    private Integer pbId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 14)
    @Column(name = "pb_finan_cnpj")
    private String pbFinanCnpj;
    @Size(max = 80)
    @Column(name = "pb_finan_raz_social")
    private String pbFinanRazSocial;
    @Size(max = 10)
    @Column(name = "pb_finan_cod_detran")
    private String pbFinanCodDetran;
    @Size(max = 10)
    @Column(name = "pb_finan_cep")
    private String pbFinanCep;
    @Size(max = 512)
    @Column(name = "pb_finan_logr")
    private String pbFinanLogr;
    @Size(max = 10)
    @Column(name = "pb_finan_num")
    private String pbFinanNum;
    @Size(max = 2)
    @Column(name = "pb_finan_uf")
    private String pbFinanUf;
    @Size(max = 512)
    @Column(name = "pb_finan_cidade")
    private String pbFinanCidade;
    @Size(max = 12)
    @Column(name = "pb_finan_bairro")
    private String pbFinanBairro;
    @Size(max = 512)
    @Column(name = "pb_finan_cidade_acad")
    private String pbFinanCidadeAcad;
    @Size(max = 12)
    @Column(name = "pb_finan_comple")
    private String pbFinanComple;
    @Size(max = 512)
    @Column(name = "pb_finan_email")
    private String pbFinanEmail;
    @Size(max = 512)
    @Column(name = "pb_finan_tel")
    private String pbFinanTel;
    @Size(max = 512)
    @Column(name = "pb_finan_cel")
    private String pbFinanCel;
    @Column(name = "pb_dt_reg")
    @Temporal(TemporalType.TIME)
    private Date pbDtReg;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "pb_dt_ult_atu")
    private String pbDtUltAtu;

    public PbInstFinan() {
    }

    public PbInstFinan(Integer pbId) {
        this.pbId = pbId;
    }

    public PbInstFinan(Integer pbId, String pbFinanCnpj, String pbDtUltAtu) {
        this.pbId = pbId;
        this.pbFinanCnpj = pbFinanCnpj;
        this.pbDtUltAtu = pbDtUltAtu;
    }

    public Integer getPbId() {
        return pbId;
    }

    public void setPbId(Integer pbId) {
        this.pbId = pbId;
    }

    public String getPbFinanCnpj() {
        return pbFinanCnpj;
    }

    public void setPbFinanCnpj(String pbFinanCnpj) {
        this.pbFinanCnpj = pbFinanCnpj;
    }

    public String getPbFinanRazSocial() {
        return pbFinanRazSocial;
    }

    public void setPbFinanRazSocial(String pbFinanRazSocial) {
        this.pbFinanRazSocial = pbFinanRazSocial;
    }

    public String getPbFinanCodDetran() {
        return pbFinanCodDetran;
    }

    public void setPbFinanCodDetran(String pbFinanCodDetran) {
        this.pbFinanCodDetran = pbFinanCodDetran;
    }

    public String getPbFinanCep() {
        return pbFinanCep;
    }

    public void setPbFinanCep(String pbFinanCep) {
        this.pbFinanCep = pbFinanCep;
    }

    public String getPbFinanLogr() {
        return pbFinanLogr;
    }

    public void setPbFinanLogr(String pbFinanLogr) {
        this.pbFinanLogr = pbFinanLogr;
    }

    public String getPbFinanNum() {
        return pbFinanNum;
    }

    public void setPbFinanNum(String pbFinanNum) {
        this.pbFinanNum = pbFinanNum;
    }

    public String getPbFinanUf() {
        return pbFinanUf;
    }

    public void setPbFinanUf(String pbFinanUf) {
        this.pbFinanUf = pbFinanUf;
    }

    public String getPbFinanCidade() {
        return pbFinanCidade;
    }

    public void setPbFinanCidade(String pbFinanCidade) {
        this.pbFinanCidade = pbFinanCidade;
    }

    public String getPbFinanBairro() {
        return pbFinanBairro;
    }

    public void setPbFinanBairro(String pbFinanBairro) {
        this.pbFinanBairro = pbFinanBairro;
    }

    public String getPbFinanCidadeAcad() {
        return pbFinanCidadeAcad;
    }

    public void setPbFinanCidadeAcad(String pbFinanCidadeAcad) {
        this.pbFinanCidadeAcad = pbFinanCidadeAcad;
    }

    public String getPbFinanComple() {
        return pbFinanComple;
    }

    public void setPbFinanComple(String pbFinanComple) {
        this.pbFinanComple = pbFinanComple;
    }

    public String getPbFinanEmail() {
        return pbFinanEmail;
    }

    public void setPbFinanEmail(String pbFinanEmail) {
        this.pbFinanEmail = pbFinanEmail;
    }

    public String getPbFinanTel() {
        return pbFinanTel;
    }

    public void setPbFinanTel(String pbFinanTel) {
        this.pbFinanTel = pbFinanTel;
    }

    public String getPbFinanCel() {
        return pbFinanCel;
    }

    public void setPbFinanCel(String pbFinanCel) {
        this.pbFinanCel = pbFinanCel;
    }

    public Date getPbDtReg() {
        return pbDtReg;
    }

    public void setPbDtReg(Date pbDtReg) {
        this.pbDtReg = pbDtReg;
    }

    public String getPbDtUltAtu() {
        return pbDtUltAtu;
    }

    public void setPbDtUltAtu(String pbDtUltAtu) {
        this.pbDtUltAtu = pbDtUltAtu;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pbId != null ? pbId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PbInstFinan)) {
            return false;
        }
        PbInstFinan other = (PbInstFinan) object;
        if ((this.pbId == null && other.pbId != null) || (this.pbId != null && !this.pbId.equals(other.pbId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.com.reconv.entitys.PbInstFinan[ pbId=" + pbId + " ]";
    }
    
}
