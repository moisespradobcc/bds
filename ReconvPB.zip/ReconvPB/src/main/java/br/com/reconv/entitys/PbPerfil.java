/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.reconv.entitys;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author cdi_mfprado
 */
@Entity
@Table(name = "pb_perfil")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PbPerfil.findAll", query = "SELECT p FROM PbPerfil p")
    , @NamedQuery(name = "PbPerfil.findByPerfilId", query = "SELECT p FROM PbPerfil p WHERE p.perfilId = :perfilId")
    , @NamedQuery(name = "PbPerfil.findByPerfilDesc", query = "SELECT p FROM PbPerfil p WHERE p.perfilDesc = :perfilDesc")
    , @NamedQuery(name = "PbPerfil.findByPerfilIdUsuIns", query = "SELECT p FROM PbPerfil p WHERE p.perfilIdUsuIns = :perfilIdUsuIns")
    , @NamedQuery(name = "PbPerfil.findByPerfilDtReg", query = "SELECT p FROM PbPerfil p WHERE p.perfilDtReg = :perfilDtReg")
    , @NamedQuery(name = "PbPerfil.findByPerfilDtUltAtu", query = "SELECT p FROM PbPerfil p WHERE p.perfilDtUltAtu = :perfilDtUltAtu")})
public class PbPerfil implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "perfil_id")
    private Integer perfilId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "perfil_desc")
    private String perfilDesc;
    @Basic(optional = false)
    @NotNull
    @Column(name = "perfil_id_usu_ins")
    private int perfilIdUsuIns;
    @Basic(optional = false)
    @NotNull
    @Column(name = "perfil_dt_reg")
    @Temporal(TemporalType.TIMESTAMP)
    private Date perfilDtReg;
    @Column(name = "perfil_dt_ult_atu")
    @Temporal(TemporalType.TIMESTAMP)
    private Date perfilDtUltAtu;

    public PbPerfil() {
    }

    public PbPerfil(Integer perfilId) {
        this.perfilId = perfilId;
    }

    public PbPerfil(Integer perfilId, String perfilDesc, int perfilIdUsuIns, Date perfilDtReg) {
        this.perfilId = perfilId;
        this.perfilDesc = perfilDesc;
        this.perfilIdUsuIns = perfilIdUsuIns;
        this.perfilDtReg = perfilDtReg;
    }

    public Integer getPerfilId() {
        return perfilId;
    }

    public void setPerfilId(Integer perfilId) {
        this.perfilId = perfilId;
    }

    public String getPerfilDesc() {
        return perfilDesc;
    }

    public void setPerfilDesc(String perfilDesc) {
        this.perfilDesc = perfilDesc;
    }

    public int getPerfilIdUsuIns() {
        return perfilIdUsuIns;
    }

    public void setPerfilIdUsuIns(int perfilIdUsuIns) {
        this.perfilIdUsuIns = perfilIdUsuIns;
    }

    public Date getPerfilDtReg() {
        return perfilDtReg;
    }

    public void setPerfilDtReg(Date perfilDtReg) {
        this.perfilDtReg = perfilDtReg;
    }

    public Date getPerfilDtUltAtu() {
        return perfilDtUltAtu;
    }

    public void setPerfilDtUltAtu(Date perfilDtUltAtu) {
        this.perfilDtUltAtu = perfilDtUltAtu;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (perfilId != null ? perfilId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PbPerfil)) {
            return false;
        }
        PbPerfil other = (PbPerfil) object;
        if ((this.perfilId == null && other.perfilId != null) || (this.perfilId != null && !this.perfilId.equals(other.perfilId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.com.reconv.entitys.PbPerfil[ perfilId=" + perfilId + " ]";
    }
    
}
