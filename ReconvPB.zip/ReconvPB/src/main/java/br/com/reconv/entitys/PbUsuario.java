/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.reconv.entitys;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author cdi_mfprado
 */
@Entity
@Table(name = "pb_usuario")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PbUsuario.findAll", query = "SELECT p FROM PbUsuario p")
    , @NamedQuery(name = "PbUsuario.findByUsuId", query = "SELECT p FROM PbUsuario p WHERE p.usuId = :usuId")
    , @NamedQuery(name = "PbUsuario.findByUsuIdPerfil", query = "SELECT p FROM PbUsuario p WHERE p.usuIdPerfil = :usuIdPerfil")
    , @NamedQuery(name = "PbUsuario.findByUsuEmail", query = "SELECT p FROM PbUsuario p WHERE p.usuEmail = :usuEmail")
    , @NamedQuery(name = "PbUsuario.findByUsuNome", query = "SELECT p FROM PbUsuario p WHERE p.usuNome = :usuNome")
    , @NamedQuery(name = "PbUsuario.findByUsuSenha", query = "SELECT p FROM PbUsuario p WHERE p.usuSenha = :usuSenha")
    , @NamedQuery(name = "PbUsuario.findByUsuDtNasc", query = "SELECT p FROM PbUsuario p WHERE p.usuDtNasc = :usuDtNasc")
    , @NamedQuery(name = "PbUsuario.findByUsuDtReg", query = "SELECT p FROM PbUsuario p WHERE p.usuDtReg = :usuDtReg")
    , @NamedQuery(name = "PbUsuario.findByUsuDtUltAtu", query = "SELECT p FROM PbUsuario p WHERE p.usuDtUltAtu = :usuDtUltAtu")})
public class PbUsuario implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "usu_id")
    private Integer usuId;
    @Column(name = "usu_id_perfil")
    private Integer usuIdPerfil;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "usu_email")
    private String usuEmail;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "usu_nome")
    private String usuNome;
    @Size(max = 8)
    @Column(name = "usu_senha")
    private String usuSenha;
    @Basic(optional = false)
    @NotNull
    @Column(name = "usu_dt_nasc")
    @Temporal(TemporalType.TIMESTAMP)
    private Date usuDtNasc;
    @Column(name = "usu_dt_reg")
    @Temporal(TemporalType.TIMESTAMP)
    private Date usuDtReg;
    @Column(name = "usu_dt_ult_atu")
    @Temporal(TemporalType.TIMESTAMP)
    private Date usuDtUltAtu;

    public PbUsuario() {
    }

    public PbUsuario(Integer usuId) {
        this.usuId = usuId;
    }

    public PbUsuario(Integer usuId, String usuEmail, String usuNome, Date usuDtNasc) {
        this.usuId = usuId;
        this.usuEmail = usuEmail;
        this.usuNome = usuNome;
        this.usuDtNasc = usuDtNasc;
    }

    public Integer getUsuId() {
        return usuId;
    }

    public void setUsuId(Integer usuId) {
        this.usuId = usuId;
    }

    public Integer getUsuIdPerfil() {
        return usuIdPerfil;
    }

    public void setUsuIdPerfil(Integer usuIdPerfil) {
        this.usuIdPerfil = usuIdPerfil;
    }

    public String getUsuEmail() {
        return usuEmail;
    }

    public void setUsuEmail(String usuEmail) {
        this.usuEmail = usuEmail;
    }

    public String getUsuNome() {
        return usuNome;
    }

    public void setUsuNome(String usuNome) {
        this.usuNome = usuNome;
    }

    public String getUsuSenha() {
        return usuSenha;
    }

    public void setUsuSenha(String usuSenha) {
        this.usuSenha = usuSenha;
    }

    public Date getUsuDtNasc() {
        return usuDtNasc;
    }

    public void setUsuDtNasc(Date usuDtNasc) {
        this.usuDtNasc = usuDtNasc;
    }

    public Date getUsuDtReg() {
        return usuDtReg;
    }

    public void setUsuDtReg(Date usuDtReg) {
        this.usuDtReg = usuDtReg;
    }

    public Date getUsuDtUltAtu() {
        return usuDtUltAtu;
    }

    public void setUsuDtUltAtu(Date usuDtUltAtu) {
        this.usuDtUltAtu = usuDtUltAtu;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (usuId != null ? usuId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PbUsuario)) {
            return false;
        }
        PbUsuario other = (PbUsuario) object;
        if ((this.usuId == null && other.usuId != null) || (this.usuId != null && !this.usuId.equals(other.usuId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.com.reconv.entitys.PbUsuario[ usuId=" + usuId + " ]";
    }
    
}
