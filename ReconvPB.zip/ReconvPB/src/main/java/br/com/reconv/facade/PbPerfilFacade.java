/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.reconv.facade;

import br.com.reconv.entitys.PbPerfil;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author cdi_mfprado
 */
@Stateless
public class PbPerfilFacade extends AbstractFacade<PbPerfil> {

    @PersistenceContext(unitName = "com.softbean_reconv-pb_war_1.0-SNAPSHOTPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PbPerfilFacade() {
        super(PbPerfil.class);
    }
    
}
